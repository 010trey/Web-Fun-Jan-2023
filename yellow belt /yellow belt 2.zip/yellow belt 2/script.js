function chooseLunch(element) {
    alert("contact us at 555-5555");
}
function buy(){
    document.querySelector("#cont-p").innerHTML++;
}
